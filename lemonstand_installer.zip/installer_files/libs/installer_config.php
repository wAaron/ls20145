<?php

	$installer_config = array();

	$installer_config['LEMONSTAND_SERVER_URL'] = 'v1.lemonstand.com';
 
?>